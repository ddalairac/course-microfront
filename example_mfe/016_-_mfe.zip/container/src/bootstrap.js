import 'products/ProductsIndex';

console.log('Container!');
